""" shameni """
from .version import version as __version__
from .shameni import Gaze
__all__ = ["shameni"]